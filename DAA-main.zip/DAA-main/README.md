# DAA [![Views](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fprashantjagtap2909%2FDAA&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=Views&edge_flat=false)](https://hits.seeyoufarm.com)

Practical Assignments and Mini Project of Design and Analysis of Algorithms.

## [Assignment]()

### Assignment 1 - [Fibonacci series](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/Fibonacci%20number.cpp)
### Assignment 2 - [0-1 knapsack](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/0-1%20knapsack.cpp)
### Assignment 3 - [Fractional knapsack](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/Fractional%20knapsack.cpp)
### Assignment 4 - [Job sequencing](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/Job%20sequencing.cpp)
### Assignment 5 - [N queen](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/N%20Queen.cpp)
### Assignment 6 - [Quicksort](https://github.com/prashantjagtap2909/DAA/blob/main/Assignments/QuickSort.cpp)


## [Mini project]()
### [Matrix chain multiplication](https://github.com/prashantjagtap2909/DAA/blob/main/MiniProject/Matrix%20Multiplication.cpp)
### [Merge sort]()
